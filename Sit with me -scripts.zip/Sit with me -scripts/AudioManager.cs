﻿using UnityEngine;

public class AudioManager : MonoBehaviour{
    
    public AudioSource Player;
    public AudioClip[] AudioSet;
    public void Awake(){
        //开机获取AudioSource组件
        Player = gameObject.GetComponent<AudioSource>();
    }
    public void PlayNote(int index) {
        /*播放对应的音频*/
        Player.PlayOneShot(AudioSet[index]);
    }
}
