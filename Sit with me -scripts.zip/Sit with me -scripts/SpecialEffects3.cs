﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class SpecialEffects3 : MonoBehaviour
{
    public Material WhiteMaterial;
    Sequence scaleSequence = null;
    [Header("那一个老奶奶模型")]
    public GameObject Model;
    [Header("动画时间")]
    public float duration;
    [Header("放大倍数")]
    public float scale;
    public bool isRun = false;
    private void Start()
    {
        OnTargetLost();
    }
    public void OnTargetFound()
    {
        if (isRun == true) {
            return;
        }

        isRun = true;
        gameObject.SetActive(true);
        Model.SetActive(false);

        // 遍历当前对象的所有子对象
        foreach (Transform child in transform)
        {
            child.localScale = Vector3.zero;
        }

        // 创建一个序列
        Sequence scaleSequence = DOTween.Sequence();
        scaleSequence.Join(WhiteMaterial.DOFade(1f, 0.01f));

        // 遍历当前对象的所有子对象
        foreach (Transform child in transform)
        {
            // 为每个子对象添加缩放动画到序列中
            scaleSequence.Join(child
                .DOScale(scale, duration)
                .SetEase(Ease.OutQuint));
        }
        scaleSequence.Join(WhiteMaterial
            .DOFade(0f, duration)
            .SetEase(Ease.InQuint)
            .OnComplete(()=> { 
                gameObject.SetActive(false);
                isRun = false;
            }));
        // 启动序列
        scaleSequence.Play();
        Invoke("OpenModel", duration*0.5f);
    }
    public void OnTargetLost()
    {
        gameObject.SetActive(false);
    }
    void OpenModel() {
        Model.SetActive(true);
    }
}
