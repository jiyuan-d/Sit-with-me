﻿using UnityEngine;
using UnityEngine.UI;

public class RotateImage : MonoBehaviour
{
    public Image image; // 指向要旋转的Image组件
    public float rotationSpeed = 100f; // 旋转速度
    public float isClosewise = 1;
    void Update()
    {
        // 计算本帧要旋转的角度
        float rotationAmount = isClosewise * rotationSpeed * Time.deltaTime;

        // 旋转Image
        image.rectTransform.Rotate(0, 0, rotationAmount);
    }
}
