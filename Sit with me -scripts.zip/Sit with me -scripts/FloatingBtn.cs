﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class FloatingBtn : MonoBehaviour
{
    [Header("动画时间")]
    public float t;
    public RectTransform MyRectTransform;
    Sequence mySequence;
    private void Awake()
    {
        MyRectTransform = gameObject.GetComponent<RectTransform>();
    }
    public void OnClick() {
        // 创建序列
        mySequence = DOTween.Sequence();
        // 先缩小
        mySequence.Append(gameObject.transform.DOScale(0.9f, t / 2));
        // 然后放大
        mySequence.Append(gameObject.transform.DOScale(1f, t / 2));
        mySequence.Play();
    }
}
