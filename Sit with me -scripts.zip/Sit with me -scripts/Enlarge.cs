﻿using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class Enlarge : MonoBehaviour
{
    public RectTransform[] ChildRectTransformSet;
    public float initScale = 0.5f;
    public float targetScale; // 放大的目标大小
    public float duration; // 放大所需时间
    public Ease e;
   
    public void OnClick()
    {
        for (int i = 0; i < ChildRectTransformSet.Length; i++) {
            RectTransform MyrectTransform = ChildRectTransformSet[i];
            MyrectTransform.localScale = initScale * Vector2.one;
            // 开始放大动画
            MyrectTransform.DOScale(targetScale, duration).SetEase(e);
            MyrectTransform.gameObject.GetComponent<CanvasGroup>().alpha = 0;
            MyrectTransform.gameObject.GetComponent<CanvasGroup>().DOFade(1, duration);
        }
    }
}
