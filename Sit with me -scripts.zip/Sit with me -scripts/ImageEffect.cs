﻿using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class ImageEffect : MonoBehaviour
{
    public Image targetImage; // 需要变化的Image
    public float targetScale; // 目标缩放
    public float duration = 1f; // 动画持续时间
    public Ease e;
    //发现“卡牌”目标的回调函数
    public void OnTargetFound()
    {
        ResetState();
        targetImage.gameObject.SetActive(true);

        Sequence mySequence = DOTween.Sequence();
        // 添加缩放和渐变动画到Sequence中
        mySequence
            // 缩放动画,在 duration 的时间内渐渐变大
            .Append(targetImage.rectTransform.DOScale(targetScale, duration).SetEase(e))
            //同时，在 duration 的时间内渐渐变不透明
            .Join(targetImage.DOFade(1, duration));
        mySequence.Play();
    }
    //“卡牌”目标消失的回调函数
    public void OnTargetLost(){
        ResetState();
        targetImage.gameObject.SetActive(false);
    }

    //先重置UI的初始状态
    //没有public,unity编辑面板不可见
    void ResetState() {
        // 将Image透明度设置为0
        Color imageColor = targetImage.color;
        imageColor.a = 0;
        targetImage.color = imageColor;
        // 将Image的初始缩放设置为0.5
        targetImage.rectTransform.localScale = Vector3.zero;
    }
}
