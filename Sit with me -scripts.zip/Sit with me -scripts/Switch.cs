using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class Switch : MonoBehaviour
{
    public bool isOpen = false;
    public RectTransform SlideRectT;
    public float a = -14f;
    public float b = 14f;

    public Color frameOnColor;
    public Color frameOffColor;
    public Color slideOnColor;
    public Color slideOffColor;

    public Image SlideImg;
    public Image FrameImg;

    public float animTime = 0.3f;
    private void Awake()
    {
        Init();
    }
    public void Init()
    {
        OnClick();
    }
    public void OnClick() {
        isOpen = !isOpen;
        if (isOpen == true){
            SlideRectT.DOAnchorPos3DX(b, animTime);

            SlideImg.DOColor(slideOnColor, animTime);
            FrameImg.DOColor(frameOnColor, animTime);
        } else {
            SlideRectT.DOAnchorPos3DX(a, animTime);

            SlideImg.DOColor(slideOffColor, animTime);
            FrameImg.DOColor(frameOffColor, animTime);
        }
    }

}
