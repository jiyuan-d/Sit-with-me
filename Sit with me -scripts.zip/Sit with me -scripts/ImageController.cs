﻿using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class ImageController : MonoBehaviour
{
    //瓶子：变量
    public Vector2 targetScale = new Vector2(1.5f, 1.5f); // 放大的目标大小
    public float duration = 1f; // 放大所需时间
    public Ease e;
    //生命周期
    void Start()
    {
        ScaleImage();
    }
    //函数，一般是回调
    void ScaleImage()
    {
        // 获取当前Image的RectTransform
        RectTransform rectTransform = gameObject.GetComponent<RectTransform>();
        rectTransform.localScale = new Vector2(1f, 1f);
        // 开始放大动画
        rectTransform.DOScale(targetScale, duration).SetEase(e);
    }
}
