﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpecialEffects2 : MonoBehaviour
{
    [Header("特效的游戏对象(演员)")]
    public GameObject GO;

    //生命周期：Start
    private void Start()
    {
        OnTargetLost();
    }

    public void OnTargetFound()
    {
        GO.SetActive(true);
        // 在一秒后调用DestroySelf方法
        Invoke("OnTargetLost", 1f);
    }

    public void OnTargetLost()
    {
        GO.SetActive(false);
    }
}
