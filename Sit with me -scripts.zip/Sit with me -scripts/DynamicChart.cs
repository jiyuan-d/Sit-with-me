﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AwesomeCharts;

public class DynamicChart : MonoBehaviour
{
    public LineChart mLineChart;
    public LineData RawDataCopy;
    [Header("让这个数据由0%演变到100%")]
    public LineData RawData;
    private void OnEnable()
    {
        Run();
    }
    public void Run(){
        StartCoroutine(CurveAnimation());
    }
    private IEnumerator CurveAnimation()
    {
        for (int k = 0; k < 100; k++){
            for (int i = 0; i < RawData.DataSets[0].Entries.Count; i++)
            {
                RawData.DataSets[0].Entries[i].Position = ((float)k / 100f) * RawDataCopy.DataSets[0].Entries[i].Position;
                RawData.DataSets[0].Entries[i].Value = ((float)k / 100f) * RawDataCopy.DataSets[0].Entries[i].Value;
            }
            mLineChart.data = RawData;
            mLineChart.SetDirty();
            yield return new WaitForSeconds(1f/100f);
        }
        yield break;
    }
}
