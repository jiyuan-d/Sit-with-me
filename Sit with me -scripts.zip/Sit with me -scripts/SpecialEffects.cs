﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpecialEffects : MonoBehaviour
{
    void OnEnable()
    {
        // 在一秒后调用DestroySelf方法
        Invoke("DestroySelf", 1f);
    }
    void DestroySelf()
    {
        gameObject.SetActive(false);
    }
}
